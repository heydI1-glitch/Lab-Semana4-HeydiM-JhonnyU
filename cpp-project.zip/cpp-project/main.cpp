#include <iostream>
#include <string>
#include <vector>
#include <stdexcept>

using namespace std;

//  dar formato de minutos:segundos
string formatoTiempo(int segundos) {
    int minutos = segundos / 60;
    int segs = segundos % 60;
    string s = (segs < 10 ? "0" : "") + to_string(segs);
    return to_string(minutos) + ":" + s;
}
// Estructura can
struct Cancion {
    string titulo;
    string artista;
    int duracion;

    string mostrar() const {
        return titulo + " - " + artista + " (" + formatoTiempo(duracion) + ")";
    }
};

// accion histoial
struct Accion {
    string tipo; // "agregar" o "eliminar"
    Cancion cancion;
    int posicion;
};

// Estructura Album
struct Album {
    string tituloAlbum;
    int anio;
    Cancion canciones[4];

    int cantidad() const {
        return 4;
    }

    int duracionTotal() const {
        int suma = 0;
        for(int i = 0; i < 4; i++) {
            suma += canciones[i].duracion;
        }
        return suma;
    }
};

// editor playlist
class EditorPlaylist {
private:
    vector<Cancion> playlist;
    PilaEstatica<Accion> historialDeshacer;
    PilaDinamica<Accion> historialRehacer;

public:
    void agregar(const Cancion& c) {
        if (historialDeshacer.estAllena()) {
            cout << "historial lleno: guarda la playlist para seguir editando\n";
            return;
        }
        playlist.push_back(c);
        Accion a;
        a.tipo = "agregar";
        a.cancion = c;
        a.posicion = playlist.size() - 1;

        historialDeshacer.push(a);
        historialRehacer = PilaDinamica<Accion>(); // Limpia rehacer
    }

    void eliminar(int pos) {
        if (historialDeshacer.estAllena()) {
            cout << "historial lleno: guarda la playlist para seguir editando\n";
            return;
        }
        if (pos < 0 || pos >= playlist.size()) {
            cout << "Posicion invalida\n";
            return;
        }
        Cancion eliminada = playlist[pos];
        playlist.erase(playlist.begin() + pos);

        Accion a;
        a.tipo = "eliminar";
        a.cancion = eliminada;
        a.posicion = pos;

        historialDeshacer.push(a);
        historialRehacer = PilaDinamica<Accion>();
    }

   


    void guardar() {
        historialDeshacer = PilaEstatica<Accion>();
        historialRehacer = PilaDinamica<Accion>();
        cout << "playlist guardada\n";
    }

 
int main() {
    // 1. Album con 4 canciones
    Album miAlbum;
    miAlbum.tituloAlbum = "grandes exitos";
    miAlbum.anio = 2024;
    miAlbum.canciones[0] = {"Cancion uno", "Artista A", 180};
    miAlbum.canciones[1] = {"Cancion dos", "Artista B", 210};
    miAlbum.canciones[2] = {"Cancion tres", "Artista C", 195};
    miAlbum.canciones[3] = {"Cancion cuatro", "Artista D", 240};

    cout << "=== ALBUM ===" << endl;
    for(int i = 0; i < 4; i++) {
        cout << i + 1 << ". " << miAlbum.canciones[i].mostrar() << endl;
    }
    cout << "Duracion total del album: " << formatoTiempo(miAlbum.duracionTotal()) << "\n\n";

    // 2. Probando la secuencia de pasos del editor
    cout << "=== SECUENCIA DE 13 PASOS ===" << endl;
    EditorPlaylist editor;

    editor.agregar(miAlbum.canciones[0]); // 1
    cout << "Paso 1 -> " << editor.obtenerEstado() << endl;

    editor.agregar(miAlbum.canciones[1]); // 2
    cout << "Paso 2 -> " << editor.obtenerEstado() << endl;

    editor.agregar(miAlbum.canciones[2]); // 3
    cout << "Paso 3 -> " << editor.obtenerEstado() << endl;

    editor.agregar(miAlbum.canciones[3]); // 4 (llena el historial de 3)
    cout << "Paso 4 -> " << editor.obtenerEstado() << endl;

    editor.deshacer(); // 5
    cout << "Paso 5 -> " << editor.obtenerEstado() << endl;

    editor.deshacer(); // 6
    cout << "Paso 6 -> " << editor.obtenerEstado() << endl;

    editor.rehacer(); // 7
    cout << "Paso 7 -> " << editor.obtenerEstado() << endl;

    editor.eliminar(0); // 8
    cout << "Paso 8 -> " << editor.obtenerEstado() << endl;

    editor.rehacer(); // 9
    cout << "Paso 9 -> " << editor.obtenerEstado() << endl;

    editor.deshacer(); // 10
    cout << "Paso 10 -> " << editor.obtenerEstado() << endl;

    editor.guardar(); // 11
    cout << "Paso 11 -> " << editor.obtenerEstado() << endl;

    editor.deshacer(); // 12
    cout << "Paso 12 -> " << editor.obtenerEstado() << endl;

    editor.agregar(miAlbum.canciones[3]); // 13
    cout << "Paso 13 -> " << editor.obtenerEstado() << endl;

    cout << "\n";
    editor.mostrarPlaylist();

    return 0;
}
